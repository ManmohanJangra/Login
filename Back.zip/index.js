const express = require('express');
// const bodyParser = require('body-parser');
const cors = require('cors');
const mongoose = require('mongoose');

const PORT = 2528;
const app = express();

app.use(express.json())
app.use(express.urlencoded({
    extended: true
}));
app.use(cors());

mongoose.connect("mongodb://0.0.0.0:27017/authentication"), {
    useNewUrlParser: true,
    useUnifiedTopology: true,
}, () => {
    console.log("Db Connected");
};

const userSchema = new mongoose.Schema({
    name: String,
    email: String,
    password: String,
});

const userModal = new mongoose.model("userModal", userSchema);

// Routes
app.post("/login", (req, res) => {
    const {email, password} = req.body;
    userModal.findOne({email: email, password: password}, (err, user) => {
        if(user){
            if(password === password){
                res.send({
                    message: "Successfully Logged In",
                    user: user,
                })
            } else {
                res.send({
                    message: "Incorrect Password"
                })
            }
        } else {
            res.send({
                message: "User Not Found"
            })
        }
    });
});

app.post("/register", (req, res) => {
    const {name, email, password} = req.body;
    userModal.findOne({email: email}, (err, user) => {
        if(user){
            res.send({message: "User Already Registered"})
        } else {
            const user = new userModal({
                name,
                email,
                password,
            })
            user.save(err => {
                if (err) {
                    res.send(err)
                } else {
                    res.send({
                        message: "Successfully Registered"
                    });
                }
            })
        }
    });
});



// PORT
app.listen(PORT, (req, res) => {
    console.log(`Server Started at port ${PORT}`);
});