import React, {useState} from "react";
import "./Register.css";
import axios from "axios";

const Register = () => {

    const [user, setUser] = useState({
        name : "",
        email: "",
        password: "",
        reEnterPassword: ""
    });

    const handleChange = (e) => {
        const {name, value} = e.target;

        console.log(name, value);

        setUser({
            ...user,
            [name]: value
        });
    }

    const register = () => {
        const {name, email, password, reEnterPassword} = user;
        if(name && email && password && reEnterPassword){
            if (password !== reEnterPassword) {
                console.log("Password doesnt match");
            }
            axios.post("http://localhost:2528/register", user)
            .then(res => {
                console.log(res);
            })
        } else {
            alert("Invalid Input");
        }

        setUser({
            name : "",
            email: "",
            password: "",
            reEnterPassword: ""
        });
    };

    return ( 
        <div className="Register">
            <h1>Register</h1>
            <input type="text" name="name" value={user.name} onChange={handleChange} placeholder="Enter Your Name"/>
            <input type="email" name="email" value={user.email} onChange={handleChange} placeholder="Enter Your Email"/>
            <input type="Password" name="password" value={user.password} onChange={handleChange} placeholder="Enter Your Password"/>
            <input type="Password" name="reEnterPassword" value={user.reEnterPassword} onChange={handleChange} placeholder="Confirm Password"/>
            <div className="button" onClick={register}>Register</div>
        </div>
    );
}

export default Register;