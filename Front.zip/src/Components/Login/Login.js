import React, {useState} from "react";
import "./Login.css";
import axios from "axios";

const Login = () => {

    const [user, setUser] = useState({
        email: "",
        password: "",
    });

    const handleChange = (e) => {
        const {
            name,
            value
        } = e.target;

        console.log(name, value);

        setUser({
            ...user,
            [name]: value
        });
    }

    const login = (e) => {
        e.preventDefault();
        axios.post("http://localhost:2528/login", user)
        .then(res => {
            console.log(res);
            if (res.data.message === "Successfully Logged In") {
                alert("Logged In");
            } else {
                alert("Please Check Credentials");
            }
        });

        setUser({
            email: "",
            password: "",
        });
    }

    return ( 
        <div className="Login">
        {console.log(user)}
            <h1>Login</h1>
            <form onSubmit={login}>
                <input type="email" name="email" value={user.email} onChange={handleChange} placeholder="Enter Your Email"/>
                <input type="Password" name="password" value={user.password} onChange={handleChange} placeholder="Enter Your Password"/>

                <button type="submit" className="button">Login</button>
            </form>
            <div className="button">Login</div>
            <div>OR</div>
            <div className="button">Register</div>
        </div>
    );
}

export default Login;