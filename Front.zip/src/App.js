import './App.css';
import Homepage from './Components/Homepage/Homepage';
import Login from './Components/Login/Login';
import Register from './Components/Register/Register';

function App() {
  return (
    <div className="App">
    {/* <Homepage /> */}
    <Login />
    {/* <Register /> */}
    </div>
  );
}

export default App;
